<script lang="ts">
	import type { CollabEditor } from "../services/collabService.svelte";

	let {
		reportId,
		onClose,
		onSave,
		onDelete,
		isSaving = false,
		isLoading = false,
		collabEditors = [],
		myColor = "",
		myName = "",
		collabActive = false,
	}: {
		reportId: string | null;
		onClose: () => void;
		onSave: () => void;
		onDelete?: () => void;
		isSaving?: boolean;
		isLoading?: boolean;
		collabEditors?: CollabEditor[];
		myColor?: string;
		myName?: string;
		collabActive?: boolean;
	} = $props();

	let showDeleteConfirm = $state(false);
	let hoveredAvatar = $state<string | null>(null);

	function getInitials(name: string): string {
		const parts = name.trim().split(/\s+/);
		if (parts.length >= 2) {
			return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
		}
		return name.substring(0, 2).toUpperCase();
	}
</script>

<div class="editor-header">
	<span class="report-title">
		{reportId ? "View Report" : "Create New Report"}
	</span>

	{#if collabActive}
		<div class="collab-section">
			<div class="collab-live-badge" class:has-others={collabEditors.length > 0}>
				<span class="live-dot"></span>
				<span class="live-text">{collabEditors.length > 0 ? 'Live Editing' : 'Connected'}</span>
			</div>
			<div class="collab-avatars">
				{#if myName && myColor}
					<div
						class="collab-avatar me"
						style="--editor-color: {myColor};"
						onmouseenter={() => hoveredAvatar = '__me__'}
						onmouseleave={() => hoveredAvatar = null}
					>
						You
						{#if hoveredAvatar === '__me__'}
							<div class="avatar-tooltip">{myName}</div>
						{/if}
					</div>
				{/if}
				{#each collabEditors as editor}
					<div
						class="collab-avatar"
						style="--editor-color: {editor.color};"
						onmouseenter={() => hoveredAvatar = editor.name}
						onmouseleave={() => hoveredAvatar = null}
					>
						{getInitials(editor.name)}
						{#if hoveredAvatar === editor.name}
							<div class="avatar-tooltip">{editor.name}</div>
						{/if}
					</div>
				{/each}
			</div>
		</div>
	{/if}

	<div class="header-actions">
		{#if reportId && onDelete}
			{#if showDeleteConfirm}
				<span class="delete-confirm-group">
					<span class="delete-confirm-text">Delete?</span>
					<button
						class="sk-btn sk-sm sk-danger"
						onclick={() => { showDeleteConfirm = false; onDelete(); }}
						type="button"
					>
						Yes
					</button>
					<button
						class="sk-btn sk-sm"
						onclick={() => (showDeleteConfirm = false)}
						type="button"
					>
						No
					</button>
				</span>
			{:else}
				<button
					class="sk-btn sk-sm sk-danger"
					onclick={() => (showDeleteConfirm = true)}
					disabled={isSaving || isLoading}
					type="button"
					aria-label="Delete report"
				>
					Delete
				</button>
			{/if}
		{/if}
		<button
			class="sk-btn sk-sm"
			onclick={onClose}
			disabled={isSaving}
			type="button"
			aria-label="Cancel report editing"
		>
			Close
		</button>
		<button
			class="sk-btn sk-sm sk-accent"
			onclick={onSave}
			disabled={isSaving || isLoading}
			type="button"
			aria-label={isSaving ? "Saving report" : "Save report"}
		>
			{isSaving ? "Saving..." : "Save"}
		</button>
	</div>
</div>

<style>
	.editor-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0 20px;
		height: 56px;
		border-bottom: 1px solid var(--border-primary);
	}

	.report-title {
		color: #fff;
		font-size: 17px;
		font-weight: 700;
	}

	.collab-section {
		display: flex;
		align-items: center;
		gap: 8px;
		margin-left: auto;
		margin-right: 12px;
	}

	.collab-live-badge {
		display: flex;
		align-items: center;
		gap: 5px;
		padding: 3px 8px;
		position: relative;
		isolation: isolate;
		margin: 0 4px;
	}

	.collab-live-badge::before {
		content: '';
		position: absolute;
		inset: 0;
		clip-path: var(--chamfer);
		background: rgba(255, 255, 255, 0.04);
		border: 1px solid rgba(255, 255, 255, 0.12);
		border-radius: 3px;
		z-index: -1;
		pointer-events: none;
	}

	.live-dot {
		width: 6px;
		height: 6px;
		border-radius: 50%;
		background: rgba(255, 255, 255, 0.35);
		animation: pulse 2s ease-in-out infinite;
	}

	.live-text {
		font-size: 9px;
		font-weight: 600;
		color: rgba(255, 255, 255, 0.4);
		text-transform: uppercase;
		letter-spacing: 0.5px;
	}

	.collab-avatars {
		display: flex;
		gap: 8px;
	}

	.collab-avatar {
		width: 24px;
		height: 24px;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 8px;
		font-weight: 700;
		color: white;
		text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
		border: none;
		margin: 0 3px;
		cursor: default;
		position: relative;
		isolation: isolate;
	}

	.collab-avatar::before { content: ''; position: absolute; inset: 0; clip-path: var(--chamfer); background: var(--editor-color, var(--accent)); border: 1px solid rgba(255, 255, 255, 0.25); border-radius: 3px; z-index: -1; pointer-events: none; }

	.collab-avatar:first-child {
		margin-left: 0;
	}

	.collab-avatar.me {
		width: auto;
		padding: 0 8px;
	}

	.avatar-tooltip {
		position: absolute;
		top: calc(100% + 6px);
		left: 50%;
		transform: translateX(-50%);
		background: rgba(0, 0, 0, 0.95);
		color: rgba(255, 255, 255, 0.9);
		font-size: 10px;
		font-weight: 500;
		padding: 4px 10px;
		border-radius: 4px;
		white-space: nowrap;
		pointer-events: none;
		z-index: 9999;
		border: 1px solid rgba(255, 255, 255, 0.12);
	}

	.avatar-tooltip::before {
		content: '';
		position: absolute;
		bottom: 100%;
		left: 50%;
		transform: translateX(-50%);
		border: 4px solid transparent;
		border-bottom-color: rgba(0, 0, 0, 0.95);
	}

	.collab-live-badge.has-others::before {
		background: rgba(34, 197, 94, 0.08);
		border-color: rgba(34, 197, 94, 0.15);
	}

	.collab-live-badge.has-others .live-text {
		color: rgba(34, 197, 94, 0.8);
	}

	.collab-live-badge.has-others .live-dot {
		background: #22c55e;
	}

	@keyframes pulse {
		0%, 100% { opacity: 1; }
		50% { opacity: 0.4; }
	}

	.header-actions {
		display: flex;
		align-items: center;
		gap: 10px;
	}

	.delete-confirm-group {
		display: flex;
		align-items: center;
		gap: 10px;
	}

	.delete-confirm-text {
		font-size: 13px;
		color: #fca5a5;
		font-weight: 700;
	}

	@media (max-width: 640px) {
		.editor-header {
			flex-direction: column;
			height: auto;
			gap: 8px;
			padding: 8px 16px;
			align-items: stretch;
		}

		.header-actions {
			justify-content: stretch;
		}
	}
</style>
