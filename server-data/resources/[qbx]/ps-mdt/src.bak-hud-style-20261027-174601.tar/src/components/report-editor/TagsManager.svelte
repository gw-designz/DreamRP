<script lang="ts">
	import { ico } from "@/icons";
	import type { TagInfo } from "../../services/tagService.svelte";

	// Hover tooltip rendered into <body> so a scrolling/overflow parent (the
	// dropdown) can never clip it; follows the cursor so it never covers a
	// neighbouring element.
	function tip(node: HTMLElement, text: string | undefined) {
		let el: HTMLDivElement | null = null;
		let cur = text;
		function place(e: MouseEvent) {
			if (!el) return;
			const t = el.getBoundingClientRect();
			let x = e.clientX + 14;
			let y = e.clientY + 16;
			if (x + t.width > window.innerWidth - 4) x = e.clientX - t.width - 14;
			if (y + t.height > window.innerHeight - 4) y = e.clientY - t.height - 16;
			el.style.left = `${Math.max(4, x)}px`;
			el.style.top = `${Math.max(4, y)}px`;
		}
		function show(e: MouseEvent) {
			if (!cur || el) return;
			el = document.createElement("div");
			el.textContent = cur;
			el.style.cssText = "position:fixed;z-index:99999;background:#111113;color:rgba(255,255,255,0.92);padding:6px 9px;border-radius:5px;font-size:11px;font-weight:500;line-height:1.4;max-width:240px;white-space:normal;word-break:break-word;border:1px solid rgba(255,255,255,0.12);box-shadow:0 8px 24px rgba(0,0,0,0.6);pointer-events:none;";
			document.body.appendChild(el);
			place(e);
		}
		function move(e: MouseEvent) { if (el) place(e); }
		function hide() { if (el) { el.remove(); el = null; } }
		node.addEventListener("mouseenter", show);
		node.addEventListener("mousemove", move);
		node.addEventListener("mouseleave", hide);
		return {
			update(v: string | undefined) { cur = v; if (el && !v) hide(); },
			destroy() { hide(); node.removeEventListener("mouseenter", show); node.removeEventListener("mousemove", move); node.removeEventListener("mouseleave", hide); },
		};
	}

	interface Props {
		tags: string[];
		availableTags: TagInfo[];
		onAddTag: (tag: string) => void;
		onRemoveTag: (index: number) => void;
		getTagColor: (tagName: string) => string;
	}

	let { tags, availableTags, onAddTag, onRemoveTag, getTagColor }: Props = $props();

	let showTagDropdown = $state(false);

	// Filter out already-selected tags
	let filteredTags = $derived(
		availableTags.filter((tag) => !tags.includes(tag.name))
	);

	function openTagDropdown() {
		showTagDropdown = true;
	}

	function addTag(tagName: string) {
		if (!tags.includes(tagName)) {
			onAddTag(tagName);
		}
		showTagDropdown = false;
	}

	function removeTag(index: number) {
		onRemoveTag(index);
	}

	function handleClickOutside(event: MouseEvent) {
		const target = event.target as HTMLElement;
		if (!target.closest(".dropdown-container")) {
			showTagDropdown = false;
		}
	}
</script>

<svelte:window on:click={handleClickOutside} />

<div class="metadata-section">
	<div class="section-title">
		<span class="section-label">Tags</span>
		<div class="dropdown-container">
			<button
				class="add-btn"
				onclick={openTagDropdown}
				title="Add Tag"
				aria-label="Add Tag"
			>+ Add</button>
			{#if showTagDropdown}
				<div class="dropdown">
					<div class="dropdown-header">Available Tags</div>
					{#each filteredTags as tag}
						<button
							class="dropdown-item"
							onclick={() => addTag(tag.name)}
							use:tip={tag.description}
						>
							<span class="tag-color-dot" style="background-color: {tag.color}"></span>
							<span class="tag-name">{tag.name}</span>
						</button>
					{/each}
					{#if filteredTags.length === 0}
						<div class="dropdown-empty">No more tags available</div>
					{/if}
				</div>
			{/if}
		</div>
	</div>
	<div class="tags-container">
		{#each tags as tag, index}
			{@const color = getTagColor(tag)}
			{@const tagDesc = availableTags.find((t) => t.name === tag)?.description}
			<div class="tag" use:tip={tagDesc} style="background-color: {color}20; border: 1px solid {color}40;">
				<span class="tag-dot" style="background-color: {color}"></span>
				<span class="tag-text" style="color: {color}">{tag}</span>
				<button
					class="remove-btn"
					onclick={() => removeTag(index)}
					aria-label="Remove tag"
				>
					<span class="material-icons svg-ico" style="font-size: 8px;">{@html ico("x_plain")}</span>
				</button>
			</div>
		{/each}
	</div>
</div>

<style>
	.metadata-section {
		padding-bottom: 12px;
		margin-bottom: 12px;
		border-bottom: 1px solid rgba(255, 255, 255, 0.04);
	}

	.section-title {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 8px;
	}

	.section-label {
		font-size: 10px;
		font-weight: 600;
		color: rgba(255, 255, 255, 0.3);
		text-transform: uppercase;
		letter-spacing: 0.6px;
	}

	.dropdown-container {
		position: relative;
	}

	.add-btn {
		background: transparent;
		border: none;
		color: rgba(255, 255, 255, 0.35);
		cursor: pointer;
		font-size: 10px;
		font-weight: 500;
		padding: 2px 6px;
		transition: color 0.1s;
	}

	.add-btn:hover {
		color: rgba(255, 255, 255, 0.5);
	}

	/* Same look as SkSelect's menu: raised panel, accent edge, skewed highlights */
	.dropdown {
		position: absolute;
		top: calc(100% + 6px);
		right: 0;
		background: var(--menu-bg);
		border: 1px solid var(--border-secondary);
		border-left: 3px solid var(--accent);
		border-radius: 4px;
		box-shadow: 0 16px 40px rgba(0, 0, 0, 0.6);
		z-index: 10000;
		min-width: 220px;
		max-height: 260px;
		overflow-y: auto;
		padding: 4px 6px 6px;
	}

	.dropdown-header {
		padding: 8px 8px 6px;
		margin-bottom: 4px;
		border-bottom: 1px solid var(--border-primary);
		font-size: 11px;
		font-weight: 700;
		color: var(--secondary-text);
		text-transform: uppercase;
		letter-spacing: 0.5px;
	}

	.dropdown-item {
		position: relative;
		isolation: isolate;
		display: flex;
		align-items: center;
		gap: 9px;
		height: 32px;
		padding: 0 14px;
		border: none;
		background: transparent;
		color: #fff;
		font-size: 13px;
		font-weight: 600;
		cursor: pointer;
		width: 100%;
		text-align: left;
	}

	.dropdown-item::before {
		content: "";
		position: absolute;
		inset: 2px 6px;
		transform: skewX(-14deg);
		border-radius: 2px;
		z-index: -1;
		transition: background 0.1s;
	}

	.dropdown-item:hover::before {
		background: rgba(var(--accent-rgb), 0.2);
		box-shadow: inset 0 0 0 1px rgba(var(--accent-rgb), 0.45);
	}

	.dropdown-empty {
		padding: 14px 10px;
		text-align: center;
		font-size: 12px;
		font-weight: 500;
		color: var(--primary-text);
	}

	.tag-color-dot {
		width: 7px;
		height: 7px;
		border-radius: 50%;
		flex-shrink: 0;
	}

	.tag-name {
		flex: 1;
	}

	.tags-container {
		display: flex;
		flex-wrap: wrap;
		gap: 4px;
	}

	.tag {
		display: flex;
		align-items: center;
		gap: 4px;
		border-radius: 3px;
		padding: 2px 7px;
		font-size: 10px;
		font-weight: 500;
	}

	.tag-dot {
		width: 5px;
		height: 5px;
		border-radius: 50%;
		flex-shrink: 0;
	}

	.tag-text {
		white-space: nowrap;
	}

	.tag:hover .remove-btn {
		opacity: 1;
	}

	.remove-btn {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 11px;
		height: 11px;
		background: rgba(239, 68, 68, 0.15);
		border: none;
		border-radius: 50%;
		color: rgba(255, 255, 255, 0.5);
		cursor: pointer;
		flex-shrink: 0;
		opacity: 0;
		transition: opacity 0.1s;
	}

	.remove-btn:hover {
		background: rgba(239, 68, 68, 0.3);
	}

	.dropdown::-webkit-scrollbar {
		width: 3px;
	}

	.dropdown::-webkit-scrollbar-track {
		background: transparent;
	}

	.dropdown::-webkit-scrollbar-thumb {
		background: rgba(255, 255, 255, 0.06);
		border-radius: 2px;
	}

	.dropdown::-webkit-scrollbar-thumb:hover {
		background: rgba(255, 255, 255, 0.1);
	}
</style>