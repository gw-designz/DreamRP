-- Speed, rpm, gear / altitude, fuel, seatbelt (with crash ejection) and the driver key hints.

local MPH, KMH, KNOTS, FEET = 2.236936, 3.6, 1.943844, 3.28084
local AIR_CLASSES = { [15] = true, [16] = true }
local getFuel

local electric = {}
for _, model in ipairs(Config.Vehicle.electric) do electric[joaat(model)] = true end

-- 'air' (helicopters / planes), 'electric' or 'car'; decides the gauge style.
local function gaugeMode(veh)
    if AIR_CLASSES[GetVehicleClass(veh)] then return 'air' end
    if electric[GetEntityModel(veh)] then return 'electric' end
    return 'car'
end

local function showHints()
    local cfg = Config.Vehicle.hints
    Hud.setHints(cfg.items, cfg.duration)
end

local function hideHints()
    Hud.setHints(nil)
end

local function resolveFuel()
    local choice = Config.Vehicle.fuel
    if choice == 'auto' then
        choice = 'native'
        for _, res in ipairs({ 'ox_fuel', 'LegacyFuel', 'cdn-fuel', 'ps-fuel', 'lj-fuel' }) do
            if GetResourceState(res) == 'started' then
                choice = res
                break
            end
        end
    end
    Bridge.debug('fuel source', choice)

    if choice == 'ox_fuel' then
        return function(veh) return Entity(veh).state.fuel or GetVehicleFuelLevel(veh) end
    elseif choice ~= 'native' then
        return function(veh) return exports[choice]:GetFuel(veh) end
    end
    -- Native fuel level is measured against the handling tank volume (usually 65L).
    return function(veh)
        local tank = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fPetrolTankVolume')
        local level = GetVehicleFuelLevel(veh)
        return tank > 0 and level / tank * 100 or level
    end
end

local function gearLabel(veh)
    if GetEntitySpeedVector(veh, true).y < -0.5 then return 'R' end
    local gear = GetVehicleCurrentGear(veh)
    if gear <= 0 then return 'N' end
    return tostring(gear)
end

local function canBelt(veh)
    return not Config.Vehicle.noBeltClasses[GetVehicleClass(veh)]
end

local function setBelt(state)
    if Hud.belted == state then return end
    Hud.belted = state
    LocalPlayer.state:set('seatbelt', state, false)
    TriggerEvent('my-hud:client:seatbelt', state)
end

local function toggleBelt()
    local veh = Hud.vehicle
    if veh == 0 or not canBelt(veh) or IsPauseMenuActive() then return end
    setBelt(not Hud.belted)
    PlaySoundFrontend(-1, Hud.belted and 'NAV_UP_DOWN' or 'NAV_LEFT_RIGHT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
end

RegisterCommand(Config.Vehicle.seatbeltCommand, toggleBelt, false)
RegisterKeyMapping(Config.Vehicle.seatbeltCommand, 'Toggle seatbelt', 'keyboard', Config.Vehicle.seatbeltKey)

local function eject(ped, veh, velocity)
    local coords = GetOffsetFromEntityInWorldCoords(veh, 0.0, 2.2, 0.8)
    SetEntityCoords(ped, coords.x, coords.y, coords.z, false, false, false, false)
    Wait(1)
    SetPedToRagdoll(ped, Config.Vehicle.eject.ragdollMs, Config.Vehicle.eject.ragdollMs, 0, false, false, false)
    SetEntityVelocity(ped, velocity.x, velocity.y, velocity.z)
    setBelt(false)
end

CreateThread(function()
    getFuel = resolveFuel()
    local lastSpeed, lastVelocity = 0.0, vector3(0, 0, 0)
    local ejectCfg = Config.Vehicle.eject
    local mode = 'car'

    while true do
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)

        if veh ~= 0 then
            if veh ~= Hud.vehicle then
                mode = gaugeMode(veh)
                if GetPedInVehicleSeat(veh, -1) == ped then showHints() else hideHints() end
            end
            Hud.vehicle = veh
            Hud.inVehicle = true

            local speed = GetEntitySpeed(veh)
            local mph = speed * MPH
            Hud.speedMph = mph
            local beltable = canBelt(veh)

            if ejectCfg.enabled and beltable and not Hud.belted
                and lastSpeed >= ejectCfg.minSpeed and lastSpeed - mph >= ejectCfg.minDelta
                and HasEntityCollidedWithAnything(veh) then
                eject(ped, veh, lastVelocity)
            end
            lastSpeed, lastVelocity = mph, GetEntityVelocity(veh)

            if Hud.visible and Hud.settings.showVehicle then
                local kmh = Hud.settings.speedUnit == 'kmh'
                local air = mode == 'air'
                local ok, fuel = pcall(getFuel, veh)
                local _, lightsOn, highBeams = GetVehicleLightsState(veh)
                local altitude = ''
                if air then
                    local height = math.max(0, GetEntityHeightAboveGround(veh))
                    altitude = kmh and ('%d m'):format(Hud.round(height)) or ('%d ft'):format(Hud.round(height * FEET))
                end
                Hud.push('vehicle', {
                    show = true,
                    mode = mode,
                    speed = Hud.round(speed * (air and KNOTS or kmh and KMH or MPH)),
                    unit = air and 'KNOTS' or kmh and 'KMH' or 'MPH',
                    altitude = altitude,
                    -- rounded to the gauge's 30 segments so idle jitter does not spam the NUI
                    rpm = Hud.round(GetVehicleCurrentRpm(veh) * 30) * 100 // 30,
                    gear = gearLabel(veh),
                    fuel = Hud.round(Hud.clamp(ok and tonumber(fuel) or 0, 0, 100)),
                    belt = beltable and Hud.belted or false,
                    beltable = beltable,
                    moving = mph > Config.Vehicle.blinkSpeed,
                    lights = lightsOn == 1 or highBeams == 1,
                    locked = GetVehicleDoorLockStatus(veh) >= 2,
                })
            else
                Hud.push('vehicle', { show = false })
            end
            Wait(Config.Tick.vehicle)
        else
            if Hud.inVehicle then
                Hud.inVehicle, Hud.vehicle, Hud.speedMph = false, 0, 0
                lastSpeed = 0.0
                setBelt(false)
                hideHints()
                Hud.push('vehicle', { show = false })
            end
            Wait(500)
        end
    end
end)

exports('IsSeatbeltOn', function() return Hud.belted end)
exports('SetSeatbelt', function(state) setBelt(state == true) end)
