'use strict';

const IS_FIVEM = typeof GetParentResourceName === 'function';
const RESOURCE = IS_FIVEM ? GetParentResourceName() : 'my-hud';

function post(name, data = {}) {
    if (!IS_FIVEM) return Promise.resolve(null);
    return fetch(`https://${RESOURCE}/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(data),
    }).then((r) => r.json()).catch(() => null);
}

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, Number(v) || 0));
const NS = 'http://www.w3.org/2000/svg';

function make(tag, className, text) {
    const e = document.createElement(tag);
    if (className) e.className = className;
    if (text !== undefined) e.textContent = text;
    return e;
}

function setText(e, text) {
    text = String(text);
    if (e.textContent !== text) e.textContent = text;
}

const root = document.documentElement;
const el = {
    hud: $('#hud'),
    strip: $('#strip'),
    voice: $('#voice'),
    minimap: $('#w-minimap'),
    map3d: $('#map3d'),
    heading: $('#heading'),
    zone: $('#zone'),
    street: $('#street'),
    cross: $('#cross'),
    locCross: $('#loc-cross'),
    wpArrow: $('.wp-arrow'),
    money: $('#w-money'),
    moneyCash: $('#money-cash'),
    moneyBank: $('#money-bank'),
    toastList: $('#toast-list'),
    controlBar: $('#control-bar'),
    gGear: $('#g-gear'),
    gLabel: $('#g-label'),
    fuelIco: $('#fuel-ico'),
    waypoint: $('#mm-waypoint'),
    wpDist: $('#wp-dist'),
    ammo: $('#w-ammo'),
    ammoClip: $('#ammo-clip'),
    ammoReserve: $('#ammo-reserve'),
    bars: $('#w-bars'),
    barStamina: $('#bar-stamina'),
    barOxygen: $('#bar-oxygen'),
    speedo: $('#w-speedo'),
    gauge: $('.gauge'),
    rpmSegs: $('#rpm-segs'),
    rpmTrack: $('#rpm-track'),
    rpmInner: $('#rpm-inner'),
    rpmTicks: $('#rpm-ticks'),
    rpmFill: $('#rpm-fill'),
    clWedge: $('#cl-wedge'),
    clTrack: $('#cl-track'),
    clTicks: $('#cl-ticks'),
    clEdge: $('#cl-edge'),
    clNeedle: $('#cl-needle'),
    clTip: $('#cl-tip'),
    fuelTrack: $('#fuel-track'),
    fuelFill: $('#fuel-fill'),
    gear: $('#gear'),
    speed: $('#speed'),
    speedDim: $('#speed-dim'),
    speedUnit: $('#speed-unit'),
    icoLights: $('#ico-lights'),
    icoBelt: $('#ico-belt'),
    icoLock: $('#ico-lock'),
    loc: $('#w-location'),
    ammoName: $('#ammo-name'),
    playerId: $('#player-id'),
    settings: $('#settings'),
    menuTabs: $('#menu-tabs'),
    menuContent: $('#menu-content'),
    menuSaved: $('#menu-saved'),
    editor: $('#editor'),
    edFrames: $('#ed-frames'),
    edList: $('#ed-list'),
    edPanel: $('#ed-panel'),
    edSize: $('#ed-size'),
    edSizeOut: $('#ed-size-out'),
    edPos: $('#ed-pos'),
    edSnap: $('#ed-snap'),
    calibrate: $('#calibrate'),
    calX: $('#cal-x'),
    calY: $('#cal-y'),
};

// One tile per stat under the minimap.
const stats = {};
$$('.st').forEach((e) => {
    stats[e.dataset.stat] = { el: e };
});

// Editor order.
const WIDGETS = {
    minimap: $('#w-minimap'),
    status: $('#w-status'),
    bars: $('#w-bars'),
    speedo: $('#w-speedo'),
    location: $('#w-location'),
    money: $('#w-money'),
    playerid: $('#w-playerid'),
    ammo: $('#w-ammo'),
    controls: $('#w-controls'),
    toasts: $('#w-toasts'),
};
const WIDGET_LABELS = {
    minimap: 'Minimap', status: 'Player status', bars: 'Stamina', speedo: 'Speedometer', location: 'Location',
    money: 'Money', playerid: 'Player ID', ammo: 'Weapon & ammo', controls: 'Key hints',
    toasts: 'Item toasts',
};

const DEFAULT_SETTINGS = {
    hudStyle: 'circuit', scale: 1.0, speedUnit: 'mph',
    showStatus: true, showVoice: true, showNeeds: true, hideFullNeeds: false, hideArmorAtZero: false,
    lowWarnings: true, showCircles: true, showBars: true, stressShake: true,
    showMinimap: true, minimapOnFoot: true, showCompass: true, showHeading: false, showLocation: true,
    showWaypoint: true, map3d: true, mapZoom: 0, mapOffsetX: 0, mapOffsetY: 0,
    showVehicle: true, beltWarning: true, showControls: true,
    showAmmo: true, showMoney: false, showPlayerId: false, showToasts: true,
    snapGrid: true,
    layout: {},
};

const state = {
    settings: JSON.parse(JSON.stringify(DEFAULT_SETTINGS)),
    config: {
        subIcons: { health: ['hunger'], armor: ['thirst', 'stress'] },
        thresholds: { lowHealth: 25, lowArmor: 25, needWarn: 30, needCrit: 15, fuelWarn: 20, oxygenCrit: 25 },
    },
    status: { health: 100, armor: 0, hunger: 100, thirst: 100, stress: 0, stamina: 100, oxygen: 100, underwater: false, dev: false },
    vehicle: { show: false, mode: 'car', speed: 0, unit: 'MPH', rpm: 0, gear: 'N', altitude: '', fuel: 100, belt: false, beltable: true, moving: false, lights: false, locked: false },
    voice: { range: 2, talking: false, radio: false, channel: 0 },
    map: { show: false },
    compass: { heading: 0 },
    location: { zone: '', street: '', cross: '', waypoint: -1, wpBearing: 0 },
    ammo: { show: false, clip: 0, reserve: 0, name: '' },
    money: { show: false, cash: 0, bank: 0, id: 0 },
    layout: { mx: 0, my: 0 },
    minimap: null,
    mode: 'hud', // 'hud' | 'menu' | 'editor' | 'calibrate'
    devAccess: false,
    dev: null, // set from DEV_DEFAULTS below
};

const kr = () => window.innerHeight / 1080;
const classic = () => state.settings.hudStyle === 'classic';

/* ---------- layout ---------- */

function getLayout(name) {
    const l = state.settings.layout[name] || {};
    return { x: Number(l.x) || 0, y: Number(l.y) || 0, s: Number(l.s) || 1 };
}

function setLayout(name, patch) {
    const next = Object.assign(getLayout(name), patch);
    if (next.x === 0 && next.y === 0 && next.s === 1) delete state.settings.layout[name];
    else state.settings.layout[name] = next;
    applyWidget(name);
}

function applyWidget(name) {
    if (name === 'minimap') return applyMinimap();
    const w = WIDGETS[name];
    const l = getLayout(name);
    w.style.setProperty('--ox', l.x);
    w.style.setProperty('--oy', l.y);
    w.style.setProperty('--s', l.s);
}

function applyLayout() {
    const h = window.innerHeight;
    const w = window.innerWidth;
    root.style.setProperty('--mx', `${state.layout.mx * w}px`);
    root.style.setProperty('--my', `${state.layout.my * h}px`);
    root.style.setProperty('--k', kr() * state.settings.scale);
    root.style.setProperty('--kr', kr());
    root.style.setProperty('--km', Math.min(h / 1080, w / 1920));
    Object.keys(WIDGETS).forEach(applyWidget);
}

// Lua sends the map center without the editor offset; the offset and size are applied
// here and in client/minimap.lua with the same formula, so frame and radar stay together.
function applyMinimap() {
    const m = state.minimap;
    if (!m) return;
    const l = getLayout('minimap');
    el.minimap.style.setProperty('--mm-w', `${m.width}px`);
    el.minimap.style.setProperty('--mm-h', `${m.height}px`);
    const x = m.cx * window.innerWidth + l.x * kr();
    const y = m.cy * window.innerHeight + l.y * kr();
    const s = m.kh * window.innerHeight * l.s;
    el.minimap.style.transform = `translate(${x}px, ${y}px) scale(${s})`;
    // 3D minimap canvas: the map rectangle plus OVERHANG (0.1 of its height) on each side
    const w = m.width * s;
    const h = m.height * s;
    const o = h * 0.1;
    Object.assign(el.map3d.style, {
        left: `${x - w / 2 - o}px`, top: `${y - h / 2 - o}px`,
        width: `${w + 2 * o}px`, height: `${h + 2 * o}px`, letterSpacing: `${2 * s}px`,
    });
}

window.addEventListener('resize', applyLayout);

/* ---------- status ---------- */

// --v (0-1) drives the tile level, or the ring in the classic style.
function setBar(name, value) {
    stats[name].el.style.setProperty('--v', clamp(value, 0, 100) / 100);
}

function levelClass(e, level, st, th) {
    e.classList.toggle('warn', st.lowWarnings && level < th.needWarn && level >= th.needCrit);
    e.classList.toggle('crit', st.lowWarnings && level < th.needCrit);
}

const setV = (e, value) => e.style.setProperty('--v', clamp(value, 0, 100) / 100);

// Extra stats (stress, oxygen, radio, dev, voice) only show while they have something to say.
function setExtra(name, show, value) {
    stats[name].el.classList.toggle('off', !show);
    setBar(name, value);
}

function renderStatus() {
    const s = state.status;
    const st = state.settings;
    const th = state.config.thresholds;

    setBar('health', s.health);
    setBar('armor', s.armor);
    stats.health.el.classList.toggle('low', st.lowWarnings && s.health <= th.lowHealth);
    stats.armor.el.classList.toggle('low', st.lowWarnings && s.armor > 0 && s.armor <= th.lowArmor);
    // the classic rings drop armor while there is none
    stats.armor.el.classList.toggle('off', (st.hideArmorAtZero || classic()) && s.armor <= 0);

    for (const name of ['hunger', 'thirst']) {
        setBar(name, s[name]);
        stats[name].el.classList.toggle('off', !st.showNeeds || (st.hideFullNeeds && s[name] >= 100));
        levelClass(stats[name].el, s[name], st, th);
    }
    setExtra('dev', Boolean(s.dev), 100);
    setExtra('stress', s.stress > 0, s.stress);
    setExtra('oxygen', Boolean(s.underwater), s.oxygen);

    // Stamina / oxygen bars only while draining.
    setV($('.sbar-fill', el.barStamina), s.stamina);
    setV($('.sbar-fill', el.barOxygen), s.oxygen);
    el.barOxygen.classList.toggle('full', !s.underwater && s.oxygen >= 100);
    el.barOxygen.classList.toggle('crit', st.lowWarnings && s.oxygen <= th.oxygenCrit);
    el.bars.classList.toggle('off', s.stamina >= 100 && s.oxygen >= 100 && !s.underwater);
}

// The mic shows while talking or tuned to a radio; its split bar is the voice range.
function renderVoice() {
    const v = state.voice;
    const range = clamp(v.range, 1, 3);
    el.voice.dataset.range = range;
    el.voice.classList.toggle('talking', Boolean(v.talking));
    el.voice.classList.toggle('radio', Boolean(v.radio));
    setExtra('voice', Boolean(v.talking || v.radio), (range / 3) * 100);
    setExtra('radio', v.channel > 0, 100);
}

/* ---------- speedometer ---------- */

// Arc angles in degrees clockwise from 12 o'clock. The RPM arc runs 0-9 (x1000) around
// the speed; the fuel arc sits outside it on the left and fills from the bottom up.
const RPM_FROM = -140;
const RPM_TO = 140;
const RPM_R = 112;
const NUM_R = 95;
const NUM_FROM = -135;
const NUM_STEP = 30;
const FUEL_R = 134;
const FUEL_FROM = -132;
const FUEL_TO = -44;
const REDLINE = 90;
const TICK_R = 121; // tick ring just outside the RPM arc; majors line up with the numerals
const TICK_STEP = 5;
const INNER_R = 78;

const polar = (r, deg) => {
    const a = (deg * Math.PI) / 180;
    return `${(Math.sin(a) * r).toFixed(2)} ${(-Math.cos(a) * r).toFixed(2)}`;
};
const arc = (r, from, to) => `M ${polar(r, from)} A ${r} ${r} 0 ${to - from > 180 ? 1 : 0} 1 ${polar(r, to)}`;

function buildGauge() {
    el.rpmTrack.setAttribute('d', arc(RPM_R, RPM_FROM, RPM_TO));
    el.rpmFill.setAttribute('d', arc(RPM_R, RPM_FROM, RPM_TO));
    const frag = document.createDocumentFragment();
    for (let i = 0; i <= 9; i++) {
        const t = document.createElementNS(NS, 'text');
        const [x, y] = polar(NUM_R, NUM_FROM + i * NUM_STEP).split(' ');
        t.setAttribute('x', x);
        t.setAttribute('y', y);
        t.textContent = String(i);
        frag.appendChild(t);
    }
    el.rpmSegs.replaceChildren(frag);
    const ticks = document.createDocumentFragment();
    for (let a = RPM_FROM; a <= RPM_TO; a += TICK_STEP) {
        const major = (a - NUM_FROM) % NUM_STEP === 0;
        const [x1, y1] = polar(TICK_R, a).split(' ');
        const [x2, y2] = polar(TICK_R + (major ? 8 : 4), a).split(' ');
        const line = document.createElementNS(NS, 'line');
        Object.entries({ x1, y1, x2, y2 }).forEach(([k, v]) => line.setAttribute(k, v));
        if (major) line.setAttribute('class', 'major');
        ticks.appendChild(line);
    }
    el.rpmTicks.replaceChildren(ticks);
    el.rpmInner.setAttribute('d', arc(INNER_R, RPM_FROM, RPM_TO));
    el.fuelTrack.setAttribute('d', arc(FUEL_R, FUEL_FROM, FUEL_TO));
    el.fuelFill.setAttribute('d', arc(FUEL_R, FUEL_FROM, FUEL_TO));
}

// Classic: a red wedge from the start of the sweep to a needle, over a tick ring.
const CL_R = 118;
const CL_FROM = -128;
const CL_TO = 128;
const CL_TICKS = 21;

function buildClassicGauge() {
    el.clTrack.setAttribute('d', arc(CL_R, CL_FROM, CL_TO));
    const frag = document.createDocumentFragment();
    for (let i = 0; i < CL_TICKS; i++) {
        const deg = CL_FROM + (i * (CL_TO - CL_FROM)) / (CL_TICKS - 1);
        const [x1, y1] = polar(CL_R - 18, deg).split(' ');
        const [x2, y2] = polar(CL_R - 12, deg).split(' ');
        const line = document.createElementNS(NS, 'line');
        Object.entries({ x1, y1, x2, y2 }).forEach(([k, v]) => line.setAttribute(k, v));
        frag.appendChild(line);
    }
    el.clTicks.replaceChildren(frag);
}

function renderClassicGauge(rpm) {
    const deg = CL_FROM + (rpm / 100) * (CL_TO - CL_FROM);
    const sweep = Math.max(deg, CL_FROM + 0.5);
    el.clWedge.setAttribute('d', `M 0 0 L ${polar(CL_R, CL_FROM)} A ${CL_R} ${CL_R} 0 ${sweep - CL_FROM > 180 ? 1 : 0} 1 ${polar(CL_R, sweep)} Z`);
    el.clEdge.setAttribute('d', arc(CL_R, CL_FROM, sweep));
    const [x1, y1] = polar(18, deg).split(' ');
    const [x2, y2] = polar(CL_R, deg).split(' ');
    Object.entries({ x1, y1, x2, y2 }).forEach(([k, v]) => el.clNeedle.setAttribute(k, v));
    el.clTip.setAttribute('cx', x2);
    el.clTip.setAttribute('cy', y2);
}

const UNIT_LABELS = { MPH: 'MP/H', KMH: 'KM/H' };
let litSegments = -1;

function renderVehicle() {
    const v = state.vehicle;
    const st = state.settings;
    const th = state.config.thresholds;
    const show = Boolean(v.show && st.showVehicle);
    el.speedo.classList.toggle('off', !show);
    el.hud.classList.toggle('in-vehicle', show);

    const rpm = clamp(v.rpm, 0, 100);
    el.rpmFill.style.setProperty('--rpm', rpm);
    el.gauge.classList.toggle('redline', rpm >= REDLINE);
    // a number lights once the arc reaches its angle
    const fillAngle = RPM_FROM + (rpm / 100) * (RPM_TO - RPM_FROM);
    const lit = rpm > 0 ? Math.floor((fillAngle - NUM_FROM) / NUM_STEP) + 1 : 0;
    if (lit !== litSegments) {
        litSegments = lit;
        el.rpmSegs.childNodes.forEach((t, i) => t.classList.toggle('on', i < lit));
    }
    renderClassicGauge(rpm);

    const speed = Math.min(999, Math.max(0, Math.round(v.speed)));
    const digits = speed > 0 ? String(speed) : '';
    setText(el.speed, digits);
    setText(el.speedDim, '0'.repeat(3 - digits.length));
    setText(el.speedUnit, classic() ? v.unit : UNIT_LABELS[String(v.unit).toUpperCase()] || v.unit);

    // car | electric | air: segment colors, plug vs pump icon, gear vs altitude
    const mode = ['car', 'electric', 'air'].includes(v.mode) ? v.mode : 'car';
    for (const m of ['car', 'electric', 'air']) el.gauge.classList.toggle(m, m === mode);
    const air = mode === 'air';
    el.gGear.classList.toggle('alt', air);
    setText(el.gear, air ? v.altitude : v.gear);
    el.fuelIco.classList.toggle('i-plug', mode === 'electric');
    el.fuelIco.classList.toggle('i-fuel', mode !== 'electric');

    el.fuelFill.style.setProperty('--fuel', clamp(v.fuel, 0, 100));
    el.gauge.classList.toggle('fuel-low', st.lowWarnings && v.fuel <= th.fuelWarn);

    el.icoLights.classList.toggle('on', Boolean(v.lights));
    el.icoLock.classList.toggle('on', Boolean(v.locked));
    // the belt icon only shows (red) while unbuckled
    const unbuckled = v.beltable && !v.belt;
    el.icoBelt.classList.toggle('alert', unbuckled);
    el.icoBelt.classList.toggle('blink', unbuckled && v.moving && st.beltWarning);
}

/* ---------- minimap ---------- */

const DIRECTIONS = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];

// Heading arrives as a compass bearing (client/main.lua converts it): 90 = east.
function renderCompass() {
    const h = Math.round(state.compass.heading) % 360;
    const dir = DIRECTIONS[Math.round(h / 45) % 8];
    setText(el.heading, state.settings.showHeading ? `${dir} ${h}°` : dir);
    renderWaypointArrow();
}

let wpRotation = 0;
let wpLastRel = null;

// The arrow points at the waypoint relative to where the camera faces (unwrapped like the ring).
function renderWaypointArrow() {
    const rel = (((state.location.wpBearing - state.compass.heading) % 360) + 360) % 360;
    wpRotation = wpLastRel === null ? rel : wpRotation + ((rel - wpLastRel + 540) % 360) - 180;
    wpLastRel = rel;
    el.wpArrow.style.setProperty('--wp-rot', `${wpRotation}deg`);
}

// Short distances switch to feet / meters.
function formatDistance(meters) {
    if (state.settings.speedUnit === 'kmh') {
        return meters < 1000 ? `${Math.round(meters / 10) * 10} m` : `${(meters / 1000).toFixed(2)} km`;
    }
    const miles = meters / 1609.344;
    return miles < 0.1 ? `${Math.round((meters * 3.28084) / 10) * 10} ft` : `${miles.toFixed(2)} mi`;
}

function renderLocation() {
    const l = state.location;
    setText(el.zone, l.zone || '');
    setText(el.street, l.street || '');
    setText(el.cross, l.cross || '');
    el.locCross.classList.toggle('off', !l.cross);
    $('#loc-zone').classList.toggle('empty', !l.zone);
    $('#loc-street').classList.toggle('empty', !l.street);
    const hasWaypoint = l.waypoint >= 0;
    el.waypoint.classList.toggle('off', !hasWaypoint);
    setText(el.wpDist, formatDistance(hasWaypoint ? l.waypoint : 0));
    renderWaypointArrow();
}

function renderMap() {
    el.minimap.classList.toggle('off', !state.map.show);
}

function renderAmmo() {
    const a = state.ammo;
    el.ammo.classList.toggle('off', !a.show);
    setText(el.ammoClip, String(a.clip).padStart(2, '0'));
    setText(el.ammoReserve, String(a.reserve).padStart(2, '0'));
    setText(el.ammoName, a.name || 'Weapon');
}

const money = (n) => `$${Math.round(Number(n) || 0).toLocaleString('en-US')}`;

function renderMoney() {
    const m = state.money;
    el.money.classList.toggle('off', !m.show);
    setText(el.moneyCash, money(m.cash));
    setText(el.moneyBank, money(m.bank));
    WIDGETS.playerid.classList.toggle('off', !(m.id > 0));
    setText(el.playerId, m.id || 0);
}

/* ---------- item toasts ---------- */

const MAX_TOASTS = 4;
const SAMPLE_TOASTS = [{ label: 'Pistol', status: 'Equipped', icon: 'gun' }, { label: 'Water', status: 'Used x1', icon: 'cup' }];

function showToast(t) {
    const card = make('div', 'toast');
    const img = make('div', 'toast-img');
    // Only nui:// and https:// images (inventory item images); anything else falls back to an icon.
    if (typeof t.image === 'string' && /^(nui|https):\/\//.test(t.image)) {
        const i = make('img');
        i.src = t.image;
        i.alt = '';
        img.appendChild(i);
    } else {
        img.appendChild(make('i', `ico i-${/^[a-z]+$/.test(t.icon || '') ? t.icon : 'gun'}`));
    }
    const body = make('div', 'toast-body');
    body.append(make('div', 'toast-name', t.label || ''), make('div', 'toast-status', t.status || ''));
    card.append(img, body);
    el.toastList.prepend(card);
    while (el.toastList.childElementCount > MAX_TOASTS) el.toastList.lastElementChild.remove();
    if (t.sticky) return;
    setTimeout(() => {
        card.classList.add('out');
        setTimeout(() => card.remove(), 320);
    }, clamp(t.duration || 4000, 1000, 15000));
}

/* ---------- controls bar ---------- */

// One bar for two channels, both resolved to final key labels by client/controls.lua:
// prompts (ShowPrompts or text UI captured from other scripts) and the vehicle key hints.
// Prompts win while they are up; hiding them brings the vehicle hints back if still active.
const controls = { prompts: null, hints: null, dev: null, sample: null };

const SAMPLE_CONTROLS = [
    { key: 'L', label: 'Lock' }, { key: 'G', label: 'Engine' }, { key: 'B', label: 'Seatbelt' },
    { key: 'H', label: 'Lights' }, { key: 'F', label: 'Exit' },
];

// Keys drawn as an icon instead of text.
const KEY_ICONS = { WHEELUP: 'i-wheel-up', WHEELDOWN: 'i-wheel-down' };

function renderControlBar() {
    const items = controls.prompts || controls.hints || controls.dev || controls.sample;
    el.controlBar.classList.toggle('off', !items);
    if (!items) return;
    const frag = document.createDocumentFragment();
    for (const item of items) {
        const p = make('div', 'prompt');
        if (item.key) {
            const icon = KEY_ICONS[item.key.toUpperCase()];
            const g = make('span', item.circle ? 'glyph circle' : 'glyph', icon ? '' : item.key);
            if (icon) {
                g.classList.add('icon');
                g.appendChild(make('i', `ico ${icon}`));
            }
            p.appendChild(g);
        }
        if (item.label) p.appendChild(make('span', 'prompt-label', item.label));
        frag.appendChild(p);
    }
    el.controlBar.replaceChildren(frag);
}

/* ---------- settings ---------- */

function applySettings() {
    const st = state.settings;
    root.dataset.style = classic() ? 'classic' : 'circuit';
    applyLayout();
    for (const name of ['health', 'armor', 'hunger', 'thirst']) stats[name].el.classList.toggle('disabled', !st.showStatus);
    el.voice.classList.toggle('disabled', !st.showVoice);
    WIDGETS.ammo.classList.toggle('disabled', !st.showAmmo);
    WIDGETS.money.classList.toggle('disabled', !st.showMoney);
    WIDGETS.playerid.classList.toggle('disabled', !st.showPlayerId);
    WIDGETS.toasts.classList.toggle('disabled', !st.showToasts);
    WIDGETS.controls.classList.toggle('disabled', !st.showControls);
    for (const name of ['stress', 'oxygen', 'radio', 'dev']) stats[name].el.classList.toggle('disabled', !st.showCircles);
    WIDGETS.bars.classList.toggle('disabled', !st.showBars);
    WIDGETS.speedo.classList.toggle('disabled', !st.showVehicle);
    el.loc.classList.toggle('no-compass', !st.showCompass);
    el.loc.classList.toggle('no-location', !st.showLocation);
    el.loc.classList.toggle('no-waypoint', !st.showWaypoint);
    WIDGETS.location.classList.toggle('disabled', !st.showCompass && !st.showLocation && !st.showWaypoint);
    el.edSnap.checked = st.snapGrid;
    renderStatus();
    renderVehicle();
    renderCompass();
    renderLocation();
}

const SAVED_TEXT = 'Saved locally for your character.';
let saveTimer = null;

function saveSettings(delay = 0) {
    clearTimeout(saveTimer);
    setText(el.menuSaved, 'Saving…');
    saveTimer = setTimeout(() => {
        post('saveSettings', state.settings).then(() => setText(el.menuSaved, SAVED_TEXT));
        if (!IS_FIVEM) setText(el.menuSaved, SAVED_TEXT);
    }, delay);
}

function changeSetting(key, value, delay = 0) {
    state.settings[key] = value;
    applySettings();
    renderControls();
    saveSettings(delay);
}

// Every row names the widget it affects (the dev panel and editor use it).
const toggle = (key, title, desc, widget) => ({ key, title, desc, widget, type: 'toggle' });
// Dev rows read and write state.dev instead of the saved settings.
const devToggle = (key, title, desc, widget) => ({ ...toggle(key, title, desc, widget), store: 'dev' });
const devRange = (key, title, widget, desc = `Value drawn while overriding, and what Apply sets.`) => ({
    key, title, desc, widget, store: 'dev', type: 'range', range: [0, 100, 5], fmt: (v) => `${v}%`,
});
const getValue = (def) => (def.store === 'dev' ? state.dev : state.settings)[def.key];
function setValue(def, value, delay) {
    if (def.store === 'dev') changeDev(def.key, value);
    else changeSetting(def.key, value, delay);
}

const PAGES = [
    {
        id: 'layout', label: 'HUD layout', icon: 'grid', title: 'HUD layout',
        desc: 'Move HUD elements around the screen and resize them independently.',
        widget: 'status', custom: true,
    },
    {
        id: 'map', label: 'Minimap', icon: 'map-wave', title: 'Map & compass', widget: 'minimap',
        desc: 'Minimap, compass and the location bar at the top of the screen.',
        rows: [
            toggle('showMinimap', 'Minimap', 'Show the framed minimap in the bottom left.', 'minimap'),
            toggle('map3d', '3D minimap', 'Draw the city in 3D with its buildings standing instead of the flat game radar. Indoors the game radar takes over.', 'minimap'),
            toggle('minimapOnFoot', 'Minimap on foot', 'Keep the minimap visible while walking, not only in vehicles.', 'minimap'),
            toggle('showCompass', 'Compass direction', 'Show the direction you face (N, NE, E ...) in the top bar.', 'location'),
            toggle('showHeading', 'Heading degrees', 'Add your heading in degrees next to the direction.', 'location'),
            toggle('showLocation', 'Location', 'Show the street and zone in the top bar.', 'location'),
            toggle('showWaypoint', 'Waypoint distance', 'Show the distance and direction to your map marker in the top bar.', 'location'),
            { key: 'mapZoom', title: 'Minimap zoom', desc: 'Lower is closer, higher shows a wider area. Auto lets the game decide.', type: 'range', range: [0, 1400, 50], fmt: (v) => (v === 0 ? 'Auto' : String(v)), widget: 'minimap' },
            { title: 'Calibrate minimap', desc: 'Fix the map if it sits off-center inside the frame.', type: 'action', label: 'Start', action: () => startCalibration(), widget: 'minimap' },
        ],
    },
    {
        id: 'status', label: 'Status', icon: 'heart-duo', title: 'Player status', widget: 'status',
        desc: 'Choose which character stats and info show on screen.',
        rows: [
            toggle('showStatus', 'Player status', 'Display the health and armor icons and bars under the minimap.', 'status'),
            toggle('showBars', 'Stamina bar', 'Show your remaining stamina while it drains.', 'bars'),
            toggle('showMoney', 'Cash & bank balances', 'Display your cash and bank balances when available from your framework.', 'money'),
            toggle('showPlayerId', 'Player ID', 'Display your current server ID. Move and resize it independently in the layout editor.', 'playerid'),
            toggle('showAmmo', 'Weapon & ammo', 'Show the equipped weapon and its available ammunition.', 'ammo'),
            toggle('showVoice', 'Voice indicator', 'Show the microphone with your voice range while talking or on the radio.', 'status'),
            toggle('showNeeds', 'Hunger & thirst', 'Show the hunger and thirst icons and bars.', 'status'),
            toggle('showCircles', 'Extra status', 'Show the dev mode, radio, stress and oxygen icons while active.', 'status'),
            toggle('lowWarnings', 'Low status warnings', 'Turn low health and armor red and tint low hunger and thirst.', 'status'),
            toggle('hideArmorAtZero', 'Hide armor at zero', 'Hide the armor icon while you have no armor.', 'status'),
            toggle('hideFullNeeds', 'Hide full need icons', 'Only show the hunger and thirst icons once they start to drop.', 'status'),
        ],
    },
    {
        id: 'vehicle', label: 'Vehicle', icon: 'car', title: 'Vehicle', widget: 'speedo',
        desc: 'Speedometer, units and driving hints.',
        rows: [
            toggle('showVehicle', 'Speedometer', 'Show speed, RPM, gear, fuel and vehicle state while driving.', 'speedo'),
            { key: 'speedUnit', title: 'Speed unit', desc: 'Units for the speedometer and the waypoint distance.', type: 'choice', options: [['mph', 'MPH'], ['kmh', 'KMH']], widget: 'speedo' },
            toggle('beltWarning', 'Seatbelt warning', 'Blink the seatbelt icon while driving unbuckled.', 'speedo'),
            toggle('showControls', 'Key hints', 'Show the key hints bar for vehicles and for every script that shows a key prompt.', 'controls'),
        ],
    },
    {
        id: 'general', label: 'General', icon: 'gear', title: 'General settings', widget: 'status',
        desc: 'Customize your HUD to fit your playstyle.',
        rows: [
            toggle('showToasts', 'Item toasts', 'Show cards on the right when you equip or use items.', 'toasts'),
            toggle('stressShake', 'Stress screen shake', 'Shake the camera while your stress is high.', 'status'),
            { key: 'hudStyle', title: 'HUD style', desc: 'Circuit: cell bars and a red RPM arc with a tick ring. Classic: ring gauges and a needle speedometer.', type: 'choice', options: [['circuit', 'Circuit'], ['classic', 'Classic']], widget: 'speedo' },
            { key: 'scale', title: 'HUD scale', desc: 'Scale every HUD element together.', type: 'range', range: [0.75, 1.25, 0.05], fmt: (v) => `${Math.round(v * 100)}%`, widget: 'status' },
        ],
    },
    {
        // Only listed for players the server allows (Config.Dev). Values here are not saved.
        id: 'dev', label: 'Dev', icon: 'code-duo', title: 'Dev tools', widget: 'status', dev: true,
        desc: 'Preview HUD states without playing them out. Nothing here is saved; Reset puts the live values back.',
        rows: [
            { title: 'Open dev panel', desc: 'Switch to a small panel docked at the side so the whole HUD stays in view.', type: 'action', label: 'Open', action: () => openDevPanel(), widget: 'status', menuOnly: true },
            devToggle('override', 'Override status values', 'Draw the values below instead of your real ones (only on your HUD).', 'status'),
            devRange('health', 'Health', 'status'),
            devRange('armor', 'Armor', 'status'),
            devRange('hunger', 'Hunger', 'status'),
            devRange('thirst', 'Thirst', 'status'),
            devRange('stress', 'Stress', 'status'),
            devRange('oxygen', 'Oxygen', 'status', 'Below 100 also shows the underwater oxygen icon.'),
            { title: 'Apply to character', desc: 'Set your real health, armor, hunger, thirst and stress to the values above.', type: 'action', label: 'Apply', action: applyDevToCharacter, widget: 'status' },
            devToggle('vehicle', 'Show speedometer', 'Show the speedometer with sample values while on foot.', 'speedo'),
            devToggle('ammo', 'Show weapon & ammo', 'Show the ammo counter with a sample weapon.', 'ammo'),
            devToggle('hints', 'Show key hints', 'Show the key hints bar with the vehicle hints.', 'controls'),
            devToggle('radio', 'Show radio', 'Show the mic in radio color and the radio icon.', 'status'),
            devToggle('devmode', 'Show dev mode icon', 'Show the green dev mode icon in the status row.', 'status'),
            { title: 'Test item toast', desc: 'Show a sample item card.', type: 'action', label: 'Show', action: () => SAMPLE_TOASTS.forEach((t) => showToast(t)), widget: 'toasts' },
            { title: 'Reset dev tools', desc: 'Turn every option here off and go back to your live values.', type: 'action', label: 'Reset', action: resetDev, widget: 'status' },
        ],
    },
];

const visiblePages = () => PAGES.filter((p) => !p.dev || state.devAccess);

// Focus model for keyboard / gamepad: the tab list on the left, or the rows.
const menu = { page: 'layout', area: 'rows', index: 0, items: [] };

function buildTabs() {
    const frag = document.createDocumentFragment();
    for (const page of visiblePages()) {
        const b = make('button', 'menu-tab');
        b.type = 'button';
        b.dataset.page = page.id;
        b.append(make('i', `ico i-${page.icon}`), make('span', '', page.label));
        b.addEventListener('click', () => {
            showPage(page.id);
            menu.area = 'tabs';
            renderFocus();
        });
        frag.appendChild(b);
    }
    el.menuTabs.replaceChildren(frag);
}

function stepItem(dir) {
    const item = menu.items[menu.index];
    if (!item) return;
    const def = item.def;
    if (def.type === 'toggle') setValue(def, !getValue(def));
    else if (def.type === 'choice') {
        const i = def.options.findIndex(([value]) => value === getValue(def));
        const next = def.options[(i + dir + def.options.length) % def.options.length][0];
        setValue(def, next);
    } else if (def.type === 'range') {
        const [min, max, step] = def.range;
        const next = Math.round(clamp(getValue(def) + dir * step, min, max) * 100) / 100;
        setValue(def, next, 150);
    }
}

function activateItem() {
    const item = menu.items[menu.index];
    if (!item) return;
    if (item.def.type === 'action') item.def.action();
    else stepItem(1);
}

// The right-hand control of a row: a switch, a slider, segmented options or a button.
function buildControl(def, index) {
    if (def.type === 'toggle') {
        const sw = make('span', 'switch');
        return { node: sw, update: () => sw.classList.toggle('on', !!getValue(def)) };
    }
    if (def.type === 'choice') {
        const seg = make('div', 'seg');
        const btns = def.options.map(([value, label]) => {
            const b = make('button', 'seg-btn', label);
            b.type = 'button';
            b.addEventListener('click', (e) => {
                e.stopPropagation();
                focusItem(index);
                setValue(def, value);
            });
            seg.appendChild(b);
            return [value, b];
        });
        return { node: seg, update: () => btns.forEach(([value, b]) => b.classList.toggle('on', value === getValue(def))) };
    }
    if (def.type === 'range') {
        const [min, max, step] = def.range;
        const wrap = make('div', 'slider');
        const input = make('input');
        Object.assign(input, { type: 'range', min, max, step });
        const out = make('output');
        input.addEventListener('input', () => {
            focusItem(index);
            setValue(def, Number(input.value), 150);
        });
        input.addEventListener('click', (e) => e.stopPropagation());
        wrap.append(input, out);
        return {
            node: wrap,
            update: () => {
                const v = getValue(def);
                if (Number(input.value) !== v) input.value = v;
                input.style.setProperty('--p', `${((v - min) / (max - min)) * 100}%`);
                setText(out, def.fmt(v));
            },
        };
    }
    return { node: make('button', 'row-btn', def.label), update: () => {} };
}

function buildRow(def, index) {
    const row = make('div', `mrow ${def.type}`);
    const text = make('div', 'mrow-text');
    text.appendChild(make('div', 'mrow-title', def.title));
    if (def.desc) text.appendChild(make('div', 'mrow-desc', def.desc));
    const control = buildControl(def, index);
    row.append(text, control.node);
    // the whole row flips a switch or runs an action, like the MDT
    row.addEventListener('click', () => {
        focusItem(index);
        if (def.type === 'toggle' || def.type === 'action') activateItem();
    });
    return { def, el: row, update: control.update };
}

function resetPositions() {
    state.settings.mapOffsetX = 0;
    state.settings.mapOffsetY = 0;
    resetLayout();
}

function buildLayoutPage(page, frag) {
    const card = make('div', 'card');
    const btn = make('button', 'card-btn', 'Open layout editor');
    btn.type = 'button';
    btn.addEventListener('click', () => openEditor());
    card.append(
        make('div', 'card-eyebrow', 'Live screen editor'),
        make('h3', '', 'Drag, move and resize'),
        make('p', '', 'Select a HUD element, move it, then use the size slider for precise scaling.'),
        btn,
    );
    card.addEventListener('mouseenter', () => focusItem(0));
    const steps = make('div', 'steps');
    ['Select element', 'Drag anywhere', 'Adjust size', 'Saved automatically'].forEach((label, i) => {
        const s = make('div', 'step');
        s.append(make('small', '', String(i + 1).padStart(2, '0')), make('span', '', label));
        steps.appendChild(s);
    });
    const reset = buildRow({
        type: 'action', label: 'Reset', action: resetPositions, widget: page.widget, title: 'Reset positions',
        desc: 'Put every element back in its default place and size, and recenter the minimap.',
    }, 1);
    const group = make('div', 'mgroup');
    group.appendChild(reset.el);
    frag.append(card, steps, group);
    const def = { type: 'action', action: () => openEditor(), widget: page.widget };
    return [{ def, el: card, update: () => {} }, reset];
}

function showPage(id) {
    const pages = visiblePages();
    const page = pages.find((p) => p.id === id) || pages[0];
    if (menu.page !== page.id) menu.index = 0;
    menu.page = page.id;
    $$('.menu-tab', el.menuTabs).forEach((b) => b.classList.toggle('on', b.dataset.page === page.id));

    const frag = document.createDocumentFragment();
    const head = make('div', 'page-head');
    head.appendChild(make('h2', '', page.title));
    if (page.desc) head.appendChild(make('p', '', page.desc));
    frag.appendChild(head);
    if (page.custom) menu.items = buildLayoutPage(page, frag);
    else {
        menu.items = page.rows.map((def, i) => buildRow(def, i));
        // runs of switches share one panel, sliders / choices / buttons another
        let group = null;
        for (const item of menu.items) {
            const kind = item.def.type === 'toggle' ? 'toggle' : 'other';
            if (!group || group.dataset.kind !== kind) {
                group = make('div', 'mgroup');
                group.dataset.kind = kind;
                frag.appendChild(group);
            }
            group.appendChild(item.el);
        }
    }
    el.menuContent.replaceChildren(frag);
    el.menuContent.scrollTop = 0;
    menu.index = Math.min(menu.index, menu.items.length - 1);
    renderControls();
    renderFocus();
}

function renderControls() {
    menu.items.forEach((item) => item.update());
}

function focusItem(index) {
    menu.area = 'rows';
    menu.index = index;
    renderFocus();
}

function renderFocus() {
    menu.items.forEach((item, i) => item.el.classList.toggle('focus', menu.area === 'rows' && i === menu.index));
    el.menuTabs.classList.toggle('focus', menu.area === 'tabs');
    const focused = menu.items[menu.index];
    if (focused && menu.area === 'rows') focused.el.scrollIntoView({ block: 'nearest' });
}

function switchTab(dir) {
    const pages = visiblePages();
    const i = pages.findIndex((p) => p.id === menu.page);
    showPage(pages[(i + dir + pages.length) % pages.length].id);
}

// Tabs run down the left, so up / down walks them there and right steps into the rows.
function menuNav(action) {
    const last = menu.items.length - 1;
    const focused = menu.items[menu.index];
    switch (action) {
        case 'up':
            if (menu.area === 'tabs') switchTab(-1);
            else if (menu.index > 0) menu.index -= 1;
            break;
        case 'down':
            if (menu.area === 'tabs') switchTab(1);
            else if (menu.index < last) menu.index += 1;
            break;
        case 'left':
        case 'right': {
            const dir = action === 'left' ? -1 : 1;
            if (menu.area === 'tabs') {
                if (dir > 0) menu.area = 'rows';
            } else if (dir < 0 && (!focused || focused.def.type === 'action')) menu.area = 'tabs';
            else stepItem(dir);
            break;
        }
        case 'prevTab': switchTab(-1); break;
        case 'nextTab': switchTab(1); break;
        case 'focus':
            menu.area = menu.area === 'tabs' ? 'rows' : 'tabs';
            break;
        case 'accept':
            if (menu.area === 'tabs') menu.area = 'rows';
            else activateItem();
            break;
        case 'back':
            return requestClose();
        default:
            return;
    }
    renderFocus();
}

function setMode(mode) {
    state.mode = mode;
    el.settings.classList.toggle('off', mode !== 'menu');
    el.editor.classList.toggle('off', mode !== 'editor');
    el.calibrate.classList.toggle('off', mode !== 'calibrate');
    $('#devpanel').classList.toggle('off', mode !== 'devpanel');
    el.hud.classList.toggle('editing', mode === 'editor');
    el.hud.classList.toggle('calibrating', mode === 'calibrate');
    // Lua blurs the game behind the menu and keeps the radar up in the editor / calibration.
    post('menuMode', { mode });
}

function openMenu() {
    showPage(menu.page);
    setMode('menu');
}

function requestClose() {
    setMode('hud');
    post('closeSettings');
}

function applyServerSettings(settings) {
    if (!settings) return;
    state.settings = Object.assign(JSON.parse(JSON.stringify(DEFAULT_SETTINGS)), settings);
    // Lua encodes an empty table as [], which would drop string keys on the next save.
    if (!state.settings.layout || Array.isArray(state.settings.layout)) state.settings.layout = {};
    applySettings();
    renderControls();
    setText(el.menuSaved, SAVED_TEXT);
}

function resetLayout() {
    state.settings.layout = {};
    applySettings();
    saveSettings();
}

$('#menu-close').addEventListener('click', requestClose);
$('#reset-all').addEventListener('click', () => {
    if (!IS_FIVEM) return applyServerSettings(DEFAULT_SETTINGS);
    post('resetSettings').then((res) => applyServerSettings(res && res.settings));
});
// Changes already save as you make them; this flushes any pending save and closes.
$('#save-close').addEventListener('click', () => {
    saveSettings();
    requestClose();
});

/* ---------- layout editor ---------- */

const GRID = 16; // snap step in 1080p px
let selected = null;
let drag = null;
let frameLoop = 0;
const frames = {};
const listItems = {};

function widgetRect(name) {
    if (name === 'minimap') return $('.mm-frame', el.minimap).getBoundingClientRect();
    const inner = { controls: el.controlBar, toasts: el.toastList, status: el.strip };
    return (inner[name] || WIDGETS[name]).getBoundingClientRect();
}

function buildEditor() {
    el.edFrames.replaceChildren();
    el.edList.replaceChildren();
    for (const name of Object.keys(WIDGETS)) {
        const item = make('button', 'ed-item', WIDGET_LABELS[name]);
        item.type = 'button';
        item.addEventListener('click', () => select(name));
        listItems[name] = item;
        el.edList.appendChild(item);

        const f = make('div', 'ed-frame');
        f.appendChild(make('span', '', WIDGET_LABELS[name]));
        f.addEventListener('pointerdown', (e) => {
            e.stopPropagation();
            select(name);
            const l = getLayout(name);
            const r = widgetRect(name);
            drag = { name, x: e.clientX, y: e.clientY, ox: l.x, oy: l.y, left: r.left, top: r.top };
            f.classList.add('dragging');
            f.setPointerCapture(e.pointerId);
        });
        f.addEventListener('pointermove', (e) => {
            if (!drag || drag.name !== name) return;
            let dx = e.clientX - drag.x;
            let dy = e.clientY - drag.y;
            // Snap the element's top-left corner to the grid, not the offset.
            if (state.settings.snapGrid) {
                const g = GRID * kr();
                dx = Math.round((drag.left + dx) / g) * g - drag.left;
                dy = Math.round((drag.top + dy) / g) * g - drag.top;
            }
            setLayout(name, { x: Math.round(drag.ox + dx / kr()), y: Math.round(drag.oy + dy / kr()) });
            if (name === 'minimap') saveSettings(120);
        });
        const end = () => {
            if (!drag) return;
            drag = null;
            f.classList.remove('dragging');
            saveSettings();
        };
        f.addEventListener('pointerup', end);
        f.addEventListener('pointercancel', end);
        frames[name] = f;
        el.edFrames.appendChild(f);
    }
}

function positionFrames() {
    for (const [name, f] of Object.entries(frames)) {
        const r = widgetRect(name);
        const pad = 6;
        f.style.left = `${r.left - pad}px`;
        f.style.top = `${r.top - pad}px`;
        f.style.width = `${r.right - r.left + pad * 2}px`;
        f.style.height = `${r.bottom - r.top + pad * 2}px`;
        if (name === selected) {
            const x = (r.left / window.innerWidth) * 100;
            const y = (r.top / window.innerHeight) * 100;
            setText(el.edPos, `X ${x.toFixed(1)} Y ${y.toFixed(1)}`);
        }
    }
    frameLoop = requestAnimationFrame(positionFrames);
}

function select(name) {
    selected = name;
    for (const [n, f] of Object.entries(frames)) f.classList.toggle('sel', n === name);
    for (const [n, b] of Object.entries(listItems)) b.classList.toggle('sel', n === name);
    el.edSize.disabled = !name;
    if (!name) setText(el.edPos, 'Select an element');
    renderEditorSize();
}

function renderEditorSize() {
    const s = selected ? getLayout(selected).s : 1;
    el.edSize.value = s;
    el.edSize.style.setProperty('--p', `${((s - 0.5) / 1) * 100}%`);
    setText(el.edSizeOut, `${Math.round(s * 100)}%`);
}

// Widgets that are empty right now get sample content so they can be positioned.
function fillEditorSamples() {
    if (!controls.prompts && !controls.hints) {
        controls.sample = SAMPLE_CONTROLS;
        renderControlBar();
    }
    if (!el.toastList.childElementCount) {
        SAMPLE_TOASTS.forEach((t) => showToast({ ...t, sticky: true }));
        el.toastList.querySelectorAll('.toast').forEach((t) => t.classList.add('sample'));
    }
}

function clearEditorSamples() {
    controls.sample = null;
    renderControlBar();
    el.toastList.querySelectorAll('.toast.sample').forEach((t) => t.remove());
}

function openEditor(name) {
    fillEditorSamples();
    setMode('editor');
    select(WIDGETS[name] ? name : null);
    cancelAnimationFrame(frameLoop);
    positionFrames();
}

function closeEditor() {
    cancelAnimationFrame(frameLoop);
    drag = null;
    clearEditorSamples();
    saveSettings();
    openMenu();
}

function cycleSelection(dir) {
    const names = Object.keys(WIDGETS);
    const i = selected ? names.indexOf(selected) : (dir > 0 ? -1 : 0);
    select(names[(i + dir + names.length) % names.length]);
}

function editorNav(action, shift) {
    const ARROW = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] }[action];
    if (action === 'back') return closeEditor();
    if (action === 'prevTab') return cycleSelection(-1);
    if (action === 'nextTab') return cycleSelection(1);
    if (!ARROW) return;
    if (!selected) return cycleSelection(1);
    const step = shift ? 10 : 1;
    const l = getLayout(selected);
    setLayout(selected, { x: l.x + ARROW[0] * step, y: l.y + ARROW[1] * step });
    saveSettings(200);
}

el.editor.addEventListener('pointerdown', () => select(null));
el.edPanel.addEventListener('pointerdown', (e) => e.stopPropagation());
el.edSize.addEventListener('input', () => {
    if (!selected) return;
    setLayout(selected, { s: Number(el.edSize.value) });
    renderEditorSize();
    saveSettings(150);
});
el.edSnap.addEventListener('change', () => changeSetting('snapGrid', el.edSnap.checked));
$('#ed-reset').addEventListener('click', () => {
    if (!selected) return;
    setLayout(selected, { x: 0, y: 0, s: 1 });
    renderEditorSize();
    saveSettings();
});
$('#ed-reset-all').addEventListener('click', () => {
    resetLayout();
    renderEditorSize();
});
$('#ed-done').addEventListener('click', closeEditor);

/* ---------- minimap calibration ---------- */

function renderCalibration() {
    setText(el.calX, state.settings.mapOffsetX);
    setText(el.calY, state.settings.mapOffsetY);
}

function startCalibration() {
    renderCalibration();
    setMode('calibrate');
}

function nudgeMap(dx, dy) {
    state.settings.mapOffsetX = clamp(state.settings.mapOffsetX + dx, -60, 60);
    state.settings.mapOffsetY = clamp(state.settings.mapOffsetY + dy, -60, 60);
    renderCalibration();
    saveSettings(80);
}

function calibrateNav(action, shift) {
    const ARROW = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] }[action];
    if (action === 'back' || action === 'accept') return openMenu();
    if (!ARROW) return;
    const step = shift ? 5 : 1;
    nudgeMap(ARROW[0] * step, ARROW[1] * step);
}

$('#cal-reset').addEventListener('click', () => nudgeMap(-state.settings.mapOffsetX, -state.settings.mapOffsetY));
$('#cal-done').addEventListener('click', openMenu);

/* ---------- keyboard + gamepad ---------- */

// One action vocabulary for both: the keyboard maps here directly, the gamepad arrives from
// Lua as 'nav' messages (d-pad, shoulders, south / east buttons).
function dispatch(action, shift = false) {
    if (state.mode === 'menu') menuNav(action);
    else if (state.mode === 'editor') editorNav(action, shift);
    else if (state.mode === 'calibrate') calibrateNav(action, shift);
    else if (state.mode === 'devpanel') devPanelNav(action);
}

const KEYS = {
    ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right',
    Tab: 'focus', ' ': 'accept', Enter: 'accept', Escape: 'back', q: 'prevTab', Q: 'prevTab', e: 'nextTab', E: 'nextTab',
};

window.addEventListener('keydown', (e) => {
    if (state.mode === 'hud') return;
    const action = KEYS[e.key];
    if (!action) return;
    // Space toggles the snap checkbox while it has focus; everything else is ours.
    if (e.target === el.edSnap && action === 'accept') return;
    e.preventDefault();
    dispatch(action, e.shiftKey);
});

/* ---------- dev menu overrides ---------- */

// Last values the game sent per group. What the HUD draws is these plus the dev overlay, so
// switching a dev option off falls straight back to the live values.
const real = {};
for (const g of ['status', 'vehicle', 'ammo', 'voice']) real[g] = { ...state[g] };

const DEV_DEFAULTS = {
    override: false, health: 100, armor: 100, hunger: 100, thirst: 100, stress: 0, oxygen: 100,
    vehicle: false, ammo: false, hints: false, radio: false, devmode: false,
};
state.dev = { ...DEV_DEFAULTS };

function devOverlay(group) {
    const d = state.dev;
    if (group === 'status') {
        const o = d.devmode ? { dev: true } : {};
        if (d.override) {
            Object.assign(o, {
                health: d.health, armor: d.armor, hunger: d.hunger, thirst: d.thirst,
                stress: d.stress, oxygen: d.oxygen, underwater: d.oxygen < 100,
            });
        }
        return o;
    }
    if (group === 'vehicle' && d.vehicle) {
        return { show: true, mode: 'car', speed: 39, unit: 'MPH', rpm: 62, gear: '2', fuel: 64, belt: false, beltable: true, moving: true, lights: true, locked: false };
    }
    if (group === 'ammo' && d.ammo) return { show: true, clip: 9, reserve: 54, name: 'Pistol' };
    if (group === 'voice' && d.radio) return { radio: true, channel: 1 };
    return {};
}

function applyGroup(group) {
    state[group] = Object.assign({}, real[group] || state[group], devOverlay(group));
    const render = renderers[group];
    if (render) render();
}

function changeDev(key, value) {
    state.dev[key] = value;
    ['status', 'vehicle', 'ammo', 'voice'].forEach(applyGroup);
    controls.dev = state.dev.hints ? SAMPLE_CONTROLS : null;
    renderControlBar();
    renderControls();
    dp.rows.forEach((r) => r.update());
}

/* ---------- compact dev panel ---------- */

// Same rows as the Dev tab, in a small panel docked left so the HUD stays visible.
const dp = { body: $('#dp-body'), rows: [], index: 0 };

function buildDevPanel() {
    const defs = PAGES.find((p) => p.id === 'dev').rows.filter((d) => !d.menuOnly);
    const frag = document.createDocumentFragment();
    let sep = false;
    dp.rows = defs.map((def, i) => {
        const row = make('div', 'dp-row');
        let update = () => {};
        if (def.type === 'action') {
            if (!sep) {
                frag.appendChild(make('div', 'dp-sep'));
                sep = true;
            }
            row.classList.add('action');
            row.textContent = def.title;
        } else {
            row.appendChild(make('span', 'dp-label', def.title));
        }
        if (def.type === 'toggle') {
            const pill = make('span', 'dp-pill');
            row.appendChild(pill);
            update = () => {
                const on = Boolean(getValue(def));
                row.classList.toggle('on', on);
                setText(pill, on ? 'On' : 'Off');
            };
        } else if (def.type === 'range') {
            const [min, max, step] = def.range;
            const input = make('input');
            Object.assign(input, { type: 'range', min, max, step });
            const out = make('output');
            input.addEventListener('input', () => setValue(def, Number(input.value)));
            input.addEventListener('click', (e) => e.stopPropagation());
            row.append(input, out);
            update = () => {
                const v = getValue(def);
                input.value = v;
                input.style.setProperty('--p', `${((v - min) / (max - min)) * 100}%`);
                setText(out, def.fmt(v));
            };
        }
        row.addEventListener('click', () => {
            dp.index = i;
            activateDevRow();
        });
        frag.appendChild(row);
        const r = { def, el: row, update };
        update();
        return r;
    });
    dp.body.replaceChildren(frag);
}

function renderDevFocus() {
    dp.rows.forEach((r, i) => r.el.classList.toggle('focus', i === dp.index));
    const r = dp.rows[dp.index];
    if (r) r.el.scrollIntoView({ block: 'nearest' });
}

function activateDevRow(dir = 1) {
    const { def } = dp.rows[dp.index] || {};
    if (!def) return;
    if (def.type === 'toggle') setValue(def, !getValue(def));
    else if (def.type === 'action') def.action();
    else if (def.type === 'range') {
        const [min, max, step] = def.range;
        setValue(def, clamp(getValue(def) + dir * step, min, max));
    }
    renderDevFocus();
}

function devPanelNav(action) {
    const last = dp.rows.length - 1;
    if (action === 'up') dp.index = Math.max(0, dp.index - 1);
    else if (action === 'down') dp.index = Math.min(last, dp.index + 1);
    else if (action === 'left' || action === 'right') {
        const { def } = dp.rows[dp.index] || {};
        if (def && def.type !== 'action') activateDevRow(action === 'left' ? -1 : 1);
    } else if (action === 'accept') activateDevRow();
    else if (action === 'back') return closeDevPanel();
    renderDevFocus();
}

function openDevPanel() {
    if (!dp.rows.length) buildDevPanel();
    setMode('devpanel');
    renderDevFocus();
}

// In game this also releases NUI focus; in the browser preview it just hides the panel.
function closeDevPanel() {
    if (IS_FIVEM) requestClose();
    else setMode('hud');
}

$('#dp-close').addEventListener('click', closeDevPanel);
$('#dp-menu').addEventListener('click', () => {
    menu.page = 'dev';
    openMenu();
});

// Browser preview: a DEV button stands in for the /huddev command.
if (!IS_FIVEM) {
    state.devAccess = true;
    const fab = $('#dev-fab');
    fab.classList.remove('off');
    fab.addEventListener('click', () => (state.mode === 'devpanel' ? setMode('hud') : openDevPanel()));
}

function resetDev() {
    Object.assign(state.dev, DEV_DEFAULTS);
    changeDev('override', false);
}

// Writes the slider values to the character itself (server checks permission again).
function applyDevToCharacter() {
    const d = state.dev;
    post('devApply', { health: d.health, armor: d.armor, hunger: d.hunger, thirst: d.thirst, stress: d.stress });
}

/* ---------- messages ---------- */

const renderers = {
    status: renderStatus,
    vehicle: renderVehicle,
    voice: renderVoice,
    map: renderMap,
    compass: renderCompass,
    location: renderLocation,
    ammo: renderAmmo,
    money: renderMoney,
};

const handlers = {
    init(d) {
        Object.assign(state.config, d.config);
        applyServerSettings(d.settings);
    },
    update(d) {
        real[d.group] = Object.assign(real[d.group] || { ...state[d.group] }, d.data);
        applyGroup(d.group);
    },
    visible(d) {
        el.hud.classList.toggle('hidden', !d.value);
    },
    layout(d) {
        state.layout = d;
        applyLayout();
    },
    minimap(d) {
        state.minimap = d;
        applyMinimap();
    },
    settings(d) {
        if (state.mode === 'hud') applyServerSettings(d.settings);
    },
    openSettings(d) {
        applyServerSettings(d.settings);
        state.devAccess = Boolean(d.dev);
        buildTabs();
        if (d.page) menu.page = d.page;
        openMenu();
    },
    closeSettings() {
        cancelAnimationFrame(frameLoop);
        if (state.mode === 'editor') clearEditorSamples();
        setMode('hud');
    },
    toast(d) {
        showToast(d);
    },
    hints(d) {
        controls.hints = d.items && d.items.length ? d.items : null;
        renderControlBar();
    },
    hideHints() {
        controls.hints = null;
        renderControlBar();
    },
    prompts(d) {
        controls.prompts = d.items && d.items.length ? d.items : null;
        renderControlBar();
    },
    hidePrompts() {
        controls.prompts = null;
        renderControlBar();
    },
    // gamepad input forwarded by client/settings.lua
    nav(d) {
        dispatch(d.key, false);
    },
};

window.addEventListener('message', (e) => {
    const d = e.data;
    if (!d || typeof d.action !== 'string') return;
    const handler = handlers[d.action];
    if (handler) handler(d);
});

buildGauge();
buildClassicGauge();
buildTabs();
buildEditor();
applySettings();
renderCompass();
renderVehicle();
post('ready');

/* ---------- browser preview (never runs in game) ---------- */

if (!IS_FIVEM && /[?&]demo\b/.test(location.search)) {
    const q = new URLSearchParams(location.search);
    const num = (key, fallback) => (q.has(key) ? Number(q.get(key)) : fallback);
    const send = (data) => window.postMessage(data, '*');
    // stand-in for the game world so white elements stay visible (&bg=none to drop it)
    if (q.get('bg') !== 'none') document.body.style.background = 'radial-gradient(ellipse at 60% 35%, #2a3138 0%, #14181c 55%, #0b0d10 100%)';
    if (q.has('scale')) state.settings.scale = num('scale', 1);
    if (q.get('style') === 'classic') state.settings.hudStyle = 'classic';
    applySettings();
    // Mirrors baseRect() in client/minimap.lua with its default config; redone on resize like Lua does.
    const map = make('div');
    if (!q.has('nomap')) document.body.prepend(map);
    // Config.Minimap and its styles.classic override
    const GEOMETRY = { circuit: [295, 193, 10, 86], classic: [295, 194, 38, 84] };
    const placeMap = () => {
        const [gw, gh, gl, gb] = GEOMETRY[state.settings.hudStyle] || GEOMETRY.circuit;
        const k = kr() * state.settings.scale;
        const mw = gw * k;
        const mh = gh * k;
        const mx = gl * k;
        const my = window.innerHeight - gb * k - mh;
        // stand-in for the game radar: grey blocks and roads like the light map style
        Object.assign(map.style, {
            position: 'fixed', left: `${mx}px`, top: `${my}px`, width: `${mw}px`, height: `${mh}px`,
            borderRadius: `${5 * k}px`, overflow: 'hidden',
            background: `linear-gradient(160deg, transparent 0 18%, #c9b25a 18% 26%, transparent 26%),
                repeating-linear-gradient(28deg, #8c9094 0 ${3 * k}px, transparent ${3 * k}px ${34 * k}px),
                repeating-linear-gradient(-62deg, #8c9094 0 ${3 * k}px, transparent ${3 * k}px ${30 * k}px),
                #5d6166`,
        });
        send({ action: 'minimap', cx: (mx + mw / 2) / window.innerWidth, cy: (my + mh / 2) / window.innerHeight, kh: k / window.innerHeight, width: gw, height: gh });
    };
    placeMap();
    window.addEventListener('resize', placeMap);
    send({ action: 'visible', value: true });
    send({ action: 'update', group: 'map', data: { show: true } });
    send({ action: 'update', group: 'compass', data: { heading: num('heading', 180) } });
    send({ action: 'update', group: 'location', data: {
        zone: q.get('style') === 'classic' ? 'Pillbox Hill' : 'Vespucci Canals', street: 'San Andreas Ave',
        cross: q.get('style') === 'classic' || q.has('cross') ? 'Peaceful St' : '',
        waypoint: num('waypoint', -1), wpBearing: num('wpbearing', 120),
    } });
    send({ action: 'update', group: 'status', data: {
        health: num('health', 100), armor: num('armor', 100), hunger: num('hunger', 75), thirst: num('thirst', 80),
        stress: num('stress', 0), stamina: num('stamina', 100), oxygen: num('oxygen', 100), underwater: q.has('underwater'),
        dev: q.has('dev'),
    } });
    send({ action: 'update', group: 'voice', data: { range: 2, talking: q.has('talking'), radio: q.has('radio'), channel: num('channel', 0) } });
    if (q.has('vehicle')) {
        const mode = q.get('vehicle') || 'car';
        send({ action: 'update', group: 'vehicle', data: {
            show: true, mode, speed: num('speed', mode === 'air' ? 90 : 28), unit: mode === 'air' ? 'KNOTS' : 'MPH',
            rpm: num('rpm', 38), gear: q.get('gear') || '2', altitude: '794 ft',
            fuel: num('fuel', 55), belt: q.has('belt'), beltable: true, moving: false, lights: true, locked: q.has('locked'),
        } });
        if (q.has('hints')) send({ action: 'hints', items: SAMPLE_CONTROLS });
    }
    if (q.has('ammo')) send({ action: 'update', group: 'ammo', data: { show: true, clip: 9, reserve: 54, name: 'Pistol' } });
    if (q.has('money')) {
        state.settings.showMoney = true;
        state.settings.showPlayerId = true;
        applySettings();
        send({ action: 'update', group: 'money', data: { show: true, cash: 48788, bank: 352655, id: 1 } });
    }
    if (q.has('toasts')) SAMPLE_TOASTS.forEach((t) => send({ action: 'toast', ...t, sticky: true }));
    if (q.has('prompts')) {
        send({ action: 'prompts', items: [
            { key: 'LT', label: 'Aim' }, { key: 'RT', label: 'Cast' },
            { key: 'B', label: 'Bait', circle: true }, { key: 'Y', label: 'Put away', circle: true },
        ] });
    }
    if (q.has('engine')) {
        send({ action: 'hints', items: [
            { key: 'WHEELUP', label: 'Engine on' }, { key: 'WHEELDOWN', label: 'Engine off' },
            { key: 'B', label: 'Seatbelt' }, { key: 'F', label: 'Exit' },
        ] });
    }
    if (q.has('settings')) {
        menu.page = q.get('tab') || 'layout';
        send({ action: 'openSettings', settings: state.settings, dev: true });
    }
    if (q.has('editor')) setTimeout(() => openEditor(q.get('editor')), 50);
    if (q.has('calibrate')) setTimeout(startCalibration, 50);
    if (q.has('devpanel')) setTimeout(openDevPanel, 50);
    if (q.has('map3d')) {
        // after map3d.js has loaded and is listening
        window.addEventListener('load', () => {
            map.style.display = 'none';
            // mirrors Config.Map3D.paint / paintNight in config.lua
            const paint = {
                land: [214, 172, 174], road: [234, 202, 204], lot: [224, 188, 190], sand: [226, 196, 190],
                footprint: [200, 152, 156], rail: [192, 148, 152], lane: [176, 122, 128, 0.3], water: [124, 120, 130],
                shallow: [150, 144, 154], roof: [198, 130, 136], wall: [170, 98, 106], haze: [238, 212, 214],
            };
            const paintNight = {
                land: [20, 18, 20], road: [58, 42, 46], lot: [30, 26, 28], sand: [34, 28, 30],
                footprint: [28, 24, 26], rail: [44, 34, 36], lane: [150, 60, 70, 0.25], water: [10, 11, 14],
                shallow: [16, 17, 22], roof: [46, 32, 36], wall: [24, 16, 18], haze: [38, 24, 28],
            };
            send({ action: 'map3d', load: true, show: true, config: { paint, paintNight } });
            send({ action: 'map3dPos', x: num('x', 215), y: num('y', -905), c: num('cam', 20), h: num('cam', 20), s: 0, g: 0 });
            if (q.has('night')) send({ action: 'map3d', night: 1 });
        });
    }
    if (q.has('spin')) {
        let h = num('heading', 180);
        setInterval(() => {
            h = (h + 3) % 360;
            send({ action: 'update', group: 'compass', data: { heading: h } });
        }, 60);
    }
}
